<?php include_once("includes/header.php"); ?> 
	<div class="crumb">
    	<p>You are Here:</p>
        <ul>
        	<li class="first"><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
        </ul>
    </div>
    <div class="clear"></div>
	<div id="content_sec">
		<div class="col1">
			<div class="contact">
				<h4 class="heading colr">Contact Us</h4>
				<div>Thank you for contacting us. We will get back to you soon !!!!</div>
			</div>
		</div>
		<div class="col2">
			<div class="contactfinder">
				<h4 class="heading colr">Where to find us.</h4>
				<a href="#" class="mapcont"><img src="./images/map2.jpeg" alt="" style="width:250px;"/></a>
				<h4>Get in touch</h4>
				<p>
					You will find our offices here<br />
					<br />
					About The Location:<br />
					Global Village Tech Park is a software technology park<br />
					The park is situated behind RVCE<br />
					<br />
					Address:<br />
					Global Village Tech Park<br />
					Mysore Road<br />
					RR Nagar<br />
					Bengaluru(Karnataka)<br />
					<br />
					Contact:<br />
					+91 (0)5654 589225<br />
					<a href="">contact@rvce.corp.in</a><br />
				</p>
			</div>
		</div>
	</div>
<?php include_once("includes/footer.php"); ?> 